setwd("C:/Users/Lucie/Documents/ECOLES/DTU/Time series analysis/Assignment 1/Final_delivery/R_files")
#### Question 1.1
include("1.1.R")
#### Question 1.2
include("1.2.R")
#### Question 1.3
include("1.3.R")
#### Question 1.4
include("1.4.R")