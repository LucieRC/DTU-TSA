setwd("..")
#### Question 1.1
include("1.1.R")
#### Question 1.2
include("1.2.R")
#### Question 1.3
include("1.3.R")
#### Question 1.4
include("1.4.R")